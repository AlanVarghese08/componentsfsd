import { Button, TextField, Typography } from "@mui/material";
import React from "react";

const Login = () => {
  return (
    <div>
      {/* <Typography variant="h3">Hello</Typography>
      <TextField variant="outlined" label="Username" />
      <br />
      <br />
      <Button>Submit</Button> */}
    </div>
  );
};

export default Login;
