import React, { useState } from "react";

const Mapping = () => {
  var [names, setname] = useState(["Alan", "Abhinav", "Jubin"]);
  return (
    <div>
      <ol>
        {names.map((value, index) => {
          return <li>{value}</li>;
        })}
      </ol>
    </div>
  );
};

export default Mapping;
