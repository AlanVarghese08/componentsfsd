import { Button, TextField, Typography } from "@mui/material";
import React, { useState } from "react";

const StateBasics = () => {
  // var name = "Alan";
  var [fname, setfname] = useState("Alan");
  var [val, setval] = useState();
  const changeName = () => {
    console.log("clicked");
    setfname(val);
    setval("");
  };
  const inputhandler = (e) => {
    console.log(e.target.value);
    setval(e.target.value);
  };
  return (
    <div>
      <Typography>My Name is {fname} </Typography>
      <TextField
        variant="outlined"
        label="Enter name"
        onChange={inputhandler}
        value={val}
      />
      <br />
      <br />
      <Button variant="contained" onClick={changeName}>
        Change
      </Button>
    </div>
  );
};

export default StateBasics;
